



filename = "languages1111111.txt"
with open(filename,"r") as fobj:
    for line in fobj:
        line = line.strip() # optional # remove white spaces if having any
        print(line)
        
print("-----------------------------------------------")

filename = "languages.txt"
with open(filename,"r") as fobj:
    for line in fobj.readlines():
        print(line)
        
print("-----------------------------------------------")        
        
filename = "languages.txt"
with open(filename,"r") as fobj:
    print(fobj.read() )    # one string

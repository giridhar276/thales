# traditional approch
fobj = open("numbers.txt","w")   # log  csv .conf .dat .txt

for val in range(20,0,-1):
    fobj.write(str(val) + "\n")
fobj.close()



alist = [10,20,30]

print(isinstance(alist,str))



alist.append(40)  # one object

print("After appending :", alist)

# alist.clear()
# print("After clearing :", alist)

getcount = alist.count(10)
print("Count of 10 :", getcount)

alist.extend([60,70,80,40,40,40])   # iterable

print(alist)

print("Get index of 20 :",alist.index(20))

# list.insert(where to insert, what to insert)
# list.insert(index, value)
alist.insert(0, 300)
print("After inserting :", alist)
alist.insert(2, 34)
print("After inserting :", alist)

removedvalue = alist.pop()  # pop the last value by default
print("List", alist)
print(removedvalue)

removedvalue = alist.pop(0)
print("List", alist)
print(removedvalue)


removedvalue = alist.pop(4)
print("List", alist)
print(removedvalue)

alist.remove(40)   # index is not provided
                   # value will be directly if exists
                   
print(alist)
         
alist.sort()  
print("After sorting :", alist)
          

alist.sort(reverse = True)   # reverse sorted order
print("After sorting :", alist)

alist.reverse()
print("After reversing :", alist)                   



for val in alist:
    print(val)


alist = [10,20,20,10,20,10,30]
unique = set(alist)
print(unique)


    




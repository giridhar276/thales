


ipadd = input("Enter IP Address:")
ilist = list(range(1,256))
iplist = ipadd.split(".")
flag = 0
for value in iplist:
    value = int(value)
    if value not in ilist :
        flag = 1
        break

if flag == 1:
    print("Invalid IP")
else:
    print("valid IP")
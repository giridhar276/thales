


alist = ["google","oracle","microsoft"]


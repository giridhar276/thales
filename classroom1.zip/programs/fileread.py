
import sys

try:
    fobj = open("abcde.txt")
    
except Exception as err:
    print(err)
    print(sys.exc_info())
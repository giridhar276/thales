
# default parameters

def add(a,b= 0,c= 0):
    print(a,b,c)
    
add(10)
add(10,20)
add(10,20,30)

## for concatinating .. Objects should be of same type

fixed = "192.168.0."

for val in range(1,11):
    print(fixed + str(val))
    
    

    
fixed = "192.168."
iprange = [0,1]

for val in iprange:
    subip = fixed + str(val)
    for value in range(1,11):
        print(subip + "." + str(value))
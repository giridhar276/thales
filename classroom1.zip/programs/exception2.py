


try:
    filename = input("Enter any filename :")
    with open(filename,"r") as fobj:
        for line in fobj:
            # will remove white spaces at both the ends
            line = line.strip()
            # will split the line based on delimeter
            output = line.split(",")
            print("Street :", output[0])
            print("City   :", output[1])

except Exception as error:
    print("System error ", error)
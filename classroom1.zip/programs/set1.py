

## unique values
aset = {10,20,10,20,20,30,40,50,60}
print(aset)

bset = {30,40,50,60}


print(aset & bset)    #  A intersection B

print(aset | bset)   #   A union B

print(aset - bset)  #   A - B

print(bset - aset)

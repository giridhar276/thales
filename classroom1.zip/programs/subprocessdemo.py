import subprocess
import os
if os.name == "nt":
    command = ['dir']
elif os.name == 'posix':
    command = ["ls","-ltr"]
p = subprocess.Popen(command ,stdout = subprocess.PIPE , stderr = subprocess.STDOUT )
out, err = p.communicate()
out = out.decode()
print(out)



filename = "languages.txt"
with open(filename,"r") as fobj:
    print(fobj.read() )    # one string

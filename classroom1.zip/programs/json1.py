

import json

try:
    with open("sample4.json","r") as fobj:
        # convert file object to json object
        with open("employeedata.csv","w") as fwrite:
            # convert file object TO json object
            data = json.load(fobj)
            for val in data.values():
                if isinstance(val,list):
                    for element in val:
                        if isinstance(element,dict):
                            # ['Joe', 'Jackson', 'male', 28, '7349282382']
                            values = list(element.values())
                            #['Joe', 'Jackson', 'male', '28', '7349282382']
                            values = list(map(lambda x:str(x) , values))
                            string = ",".join(values)
                            #print(string)
                            fwrite.write(string + "\n")
except FileNotFoundError as err:
    print(err)
except Exception as error :
    print(error)                    
    
    




# Write a Python program to count the number of characters (character frequency) in a string

name=input("Enter the string:")
aset=set(name)
for val in aset:
    if val != " ":
        count=name.count(val)
        print("Count of " +val+ " is:", count)
        
        
name = "python programming"
freq = dict()

for char in name :
    if char in freq:
        freq[char] +=1
    else:
        freq[char] =1
        
print(freq)
#Write a Python program to read 
#realestate.csv and display all the UNIQUE cities and the 
#count of unique cities.


###3
cityset = set()
with open("realestate.csv","r") as fobj:
    # 1st for loop is for the processing the data
    for line in fobj:
        # will remove white spaces at both the ends
        line = line.strip()
        # will split the line based on delimeter
        output = line.split(",")
        cityset.add(output[1])
    # displaying the output    
    for city in cityset:
        print(city)
    print()
    print("total no. of cities :", len(cityset))
        
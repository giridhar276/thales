#context switching
# If any line starts with the keyword 'with'
# it is called context switching
# the file will be closed automatically when it moves
# out of indentation

with open("numberslist.txt","w") as fobj:
    
    for val in range(20,0,-1):
        fobj.write(str(val) + "\n")

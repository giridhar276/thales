alist = [10,20,30,40]
# [15,25,35,45]
blist = []
for val in alist:
    blist.append(val + 5)
print(blist)    
    
    
alist = [10,20,30,40]
for val in alist:
    index = alist.index(val)
    alist[index] = val + 5
print(alist)


alist = [10,20,30,40]
def increment(x):
    return x + 5
print(list(map(increment, alist)))


alist = [10,20,30,40]
increment = lambda x : x + 5
print(list(map(increment, alist)))


alist = ["google","oracle","microsoft"]
append = lambda x : "http://www." + x + ".com"
print(list(map(append,alist)))


alist = [1,2,3,4,5,6,7,8,9]
check = lambda x : x%2
print(list(filter(check,alist)))

alist = ["google","unix","c","perl","java","python"]
# unix perl java
check = lambda x : len(x) == 4
print(list(filter(check,alist)))


# list comprehension
alist = [10,20,30,40]

output = [  val + 5   for val in alist]
print(output)



output = [x if x in 'aeiou' else '*' for x in 'python programming']
print(output)





















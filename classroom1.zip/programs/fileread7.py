

# pandas is used for file/data processing
import pandas

df = pandas.read_csv("languages.txt")

print(df)
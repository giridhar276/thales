


infodoc = { 2001: {"ap":76} , 2002:{"tn":75} , 2003:{"up":90} }


infodoc = { 2001: {"ap":76} , 2002:{"tn":75} , 2003:{"up":90} }
print("state literacy rate", end=("\n\n"))
print("—"*10, end=("\n\n"))
for key,val in infodoc.items():
    #print(infodoc[key])
    skey =  list(infodoc[key].keys())
    
    svalue =  list(infodoc[key].values())
    print(skey[0].ljust(10) , svalue[0])
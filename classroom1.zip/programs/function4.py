
# Variable length arguments
# If any object is pre-fixed with * , it is called as tuple


def add(*data):
    for val in data:
        print(val)
    
add(10,20,30,40,50,60,70,80,10,43,14,234,24,432)



def display(**info):
    print(info)

display(chap1=10 , chap2= 20)



def add(first,second, *data):
    print(first)
    print(second)
    print("-------------")
    for val in data:
        print(val)
    
add(10,20,30,40,50,60,70,80,10,43,14,234,24,432)


import os
import sys
try:
    allfiles =  os.listdir()
    for file in allfiles :
        print(file)
except Exception as err:
    print(err)
    # display the exception name
    print(sys.exc_info())
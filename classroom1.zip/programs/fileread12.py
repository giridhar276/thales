#4. Write a Python program to read realestate.csv and display the count of an individual city.



citylist = []
with open("realestate.csv","r") as fobj:
    # 1st for loop is for the processing the data
    for line in fobj:
        # will remove white spaces at both the ends
        line = line.strip()
        # will split the line based on delimeter
        output = line.split(",")
        city = output[1]
        citylist.append(city)
    for city in set(citylist):
        print(city.ljust(15), citylist.count(city))
        


###3-1
citydict  = dict()
with open("realestate.csv","r") as fobj:
    # 1st for loop is for the processing the data
    for line in fobj:
        # will remove white spaces at both the ends
        line = line.strip()
        # will split the line based on delimeter
        output = line.split(",")
        # If the city is already existing .... then increment
        if output[1] in citydict:
            citydict[output[1]] += 1
        else:
            citydict[output[1]] = 1
    # displaying the output    
    for city,frequency in  citydict.items():
        print(city.ljust(15), frequency)

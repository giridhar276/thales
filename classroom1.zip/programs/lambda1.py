def add(val):
    return val + 5

total = add(10)
print("total :", total)



##  lambda
## lambda is inline function
## The function body will be replaced in the function call itself 
## Advantage : the processing becomes faster
## syntax
## functionname = lambda variables : expresssion


add = lambda val : val + 5

total = add(10)
print("total :", total)



concat = lambda x,y : x + " " + y
string = concat("python","programming")
print(string)


















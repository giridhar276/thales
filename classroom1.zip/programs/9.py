

#username=input("Enter your username: ")
password=input("Enter your password: ")

if len(password) in range (6,11):
    if password.islower():
        if password.find("@") != -1 or password.find("*") != -1 or password.find("$") != -1:
            print("Password is good")
        else:
            print("Bad password")
    elif not password.islower():
        print("Bad password")
else:
    print("Password doesn't match the criterion")
    
    

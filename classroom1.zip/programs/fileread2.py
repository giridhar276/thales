
## displaying all the lines at once
## read enough for reading the config files
filename = "languages.txt"
with open(filename,"r") as fobj:
    for line in fobj.readlines():
        print(line)

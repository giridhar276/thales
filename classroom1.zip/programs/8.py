

blist = []
alist=list(input("Enter the string: "))
#acount=len(alist)

for x in range(0, len(alist)-1):
    for y in range (len(alist)-1,0):
        blist[y]=alist[x]
        print(blist[y])
        
        
name = "python"
print(name[::-1])

namelist = list(name)
#print(namelist)
namelist.reverse()
string= "".join(namelist)




filename = "languages.txt"
with open(filename,"r") as fobj:
    for line in fobj.readlines():
        line = line.strip()
        print(line)
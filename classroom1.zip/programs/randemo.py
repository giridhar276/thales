


print(list(range(10)))
print(list(range(1,10)))
print(list(range(1,10,2)))
print(list(range(2,10,2)))
print(list(range(10,0,-1)))
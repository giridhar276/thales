


aset = {10,20,30,10,20,30,30}

print(aset)

bset = {30,40,50,50,50}

print(bset)

print(aset.union(bset))

print(aset.intersection(bset))

print(aset.difference(bset))


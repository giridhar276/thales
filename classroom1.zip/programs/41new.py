
newpass=input("Please enter your Password: ")
alist=["@","*","$"]
if (len(newpass) > 5) and (len(newpass) < 12) and (newpass != newpass.upper()) and newpass in alist:
    print("Password meets validations")
else:
    print("One of the validations fail")
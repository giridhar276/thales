
### keyword arguments
def add(b,c, a):
    print(a)
    print(b)
    print(c)



add(a = 10,b = 20,c=30)



print(10,20, sep = "  ", end= "\n\n\n")

print(10,20,end = "\n\n\n\n", sep = " ")
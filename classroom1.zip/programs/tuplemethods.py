

atup = (10,20,30,40,50,10)

print(atup.count(10))



name = "python"
for char in name :
    print(char)
    
alist = [10,20,30,40]
for val in alist:
    print(val)
    
atup = (10,20,30)
print(type(atup))


print(isinstance(atup,tuple))
print(isinstance(atup,list))

name = "python"
print(isinstance(name,list))



for val in atup:
    print(val)
    

adict ={"chap1":10 ,"chap2":20}
for key in adict:
    print(key)
    print(adict[key])
    print("------------")
    
    
    
name = "python programming"
if name.count("python") > 0 :
    print("exists")
    

if name.find("python") != -1 :
    print("Exists")
    
    
if "python" in name :
    print("exists")
    
    
alist = [10,20,30]
if 10 in alist:
    print("exists")
    
    
    
    
    








alist = [10,20,30]



atup = (10,20)



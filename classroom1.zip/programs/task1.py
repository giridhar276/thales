import os
items=os.listdir()
print("Sample output")
print("--------------------")
for item in items:
    if os.path.isfile(item) and item.split(".")[1]=='py':
        print(item.ljust(30), os.path.getsize(item), "bytes")
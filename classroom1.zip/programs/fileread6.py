

import csv

with open("languages.txt") as fobj:
    # converting file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        print(line)
    
    fobj.seek(0)
    for line in reader:
        print(line)
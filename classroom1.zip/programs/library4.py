

import os
import sys
try:
    filename = "programs.txt"
    if os.path.exists(filename):
        os.unlink(filename)

    with open(filename,"w") as fw:
        allfiles =  os.listdir()
        for file in allfiles :
            #print(file)
            fw.write(file + "\n")
except Exception as err:
    print(err)
    # display the exception name
    print(sys.exc_info())
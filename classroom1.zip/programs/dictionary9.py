



book  = {"chap1":10 ,"chap2":20 ,"chap3":30 ,"chap1":1000 }

if "chap1" in book:
    # your logic
    
alist = [10,20,30]

if 10 in alist:
    # your logic
    
name ="python programming"

if 'python' in name:
    # your task


print(book)


aset = {10,20,20,30,30}


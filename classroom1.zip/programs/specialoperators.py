


val = 3 + 4

print(val)

first = "python"
second = "programming"

output = first + " " + second
print(output)

alist = [10,20,30]
blist = [40,50,60]

final = alist + blist
print(final)

adict  = {"chap1":10, "chap2":20}
bdict = {"chap3":30 ,"chap4":40}

#finaldict = adict + bdict
#print(finaldict)


finaldict = {**adict,**bdict}
print(finaldict)

name= "python"
print(name * 10)
print(alist * 3)



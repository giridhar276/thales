




import json

try:
    with open("samplejson.json","r") as fobj:
        data = json.load(fobj)
        print(data)
            
except FileNotFoundError as err:
    print(err)
except Exception as error :
    print(error)                    
    
    

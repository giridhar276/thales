alist = [10,20,30,40]
blist = ["python","perl","java"]
clist = [10,343.33,"spark"]
dlist = [[10,20],["python","pyspark"],alist] 


print(dlist)
print(dlist[0][0])
print(dlist[1])


print(alist)

print(alist[0])
# modified the first index
alist[0] = 1000

print("Output:", alist)
import os
import sys
try:
    files = []
    directories = []
    allfiles =  os.listdir()
    for file in allfiles :
        if os.path.isfile(file):
            files.append(file)
        else:
            directories.append(file) 
    ## display output
    print("########### FILES ###########")
    for file in files :
        print(file)
    print()
    print("""""""""""""DIRECTORIES ############")
    for file in directories:
        print(file)
    
except Exception as err:
    print(err)
    # display the exception name
    print(sys.exc_info())

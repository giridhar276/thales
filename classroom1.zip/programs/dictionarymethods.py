


book  = {"chap1":10 ,"chap2":20 ,"chap3":30 }
print(type(book))

if "chap2" in book:
    print("....")



print(book.keys())
print(list(book.keys()))

print(book.values())

print(book.items())

# all the keys
for key in book:
    print(key)

# all the values
for value in book.values():
    print(value)
    
for key,value in book.items():
    print(key,value)
    

print(book["chap1"])
#print(book["chap4"])

print(book.get("chap4"))
print(book.get("chap1"))


print(book.pop("chap1")) # key:value will be removed
print(book)


print(book.popitem())

book1 = {"chap5":50, "chap6":60}

#finalbook = {book,book1}
#print(finalbook)

book.update(book1)
print(book)




numbers = dict(x=10,y=100)
print(numbers)

numbers1 = dict([('x',100),('y',200)])
print(numbers1)















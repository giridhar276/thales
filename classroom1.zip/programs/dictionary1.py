


book  = {"chap1":10 ,"chap2":20 ,"chap3":30 }

print(book["chap1"])

book["chap1"] = 100

book["chap100"] =100000

print(book)

print(list(book.keys()))
print(book.values())
ipname=input("Enter the IP address : ")
iplist=ipname.split('.')
ilist=list(range(1,256))
flag=0
for value in iplist:
    value=int(value)
    if value not in ilist:
        flag=1
     
if flag==1:
    print("IP adress is Invalid  \n")
else:
    print("Valid IP address")
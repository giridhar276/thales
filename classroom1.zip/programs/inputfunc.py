

# IN python 2.x  raw_input()
# In python 3.x  input()
name = input("Enter any name :")
print(name)
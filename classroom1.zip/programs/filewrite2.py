#fobj = open("D:/new/info.txt","w")
#fobj = open(r"D:\new\info.txt","w") # raw string
#fobj = open("D:\\new\\info.txt","w")

fobj = open("info.txt","w")   # log  csv .conf .dat .txt
fobj.write("python programming\n")
fobj.write("scala programming\n")
fobj.close()




# reading line by line

# fobj acts as CURSOR for nagivating between the lines



filename = "languages.txt"
with open(filename,"r") as fobj:
    for line in fobj:
        line = line.strip() # optional # remove white spaces if having any
        print(line)
        

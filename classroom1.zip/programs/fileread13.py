# -*- coding: utf-8 -*-
"""
Created on Mon May 17 17:48:00 2021

@author: gsripath
"""


 


with open("realestate.csv","r") as fobj:
    with open("backup.csv","w") as fwrite:
        for line in fobj:
            line = line.strip()
            line = line.replace("SACRAMENTO", "BANGALORE")
            fwrite.write(line + "\n")
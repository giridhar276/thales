
uc = 0
lc = 0

string = input("Enter any string")

for char in string:
    if char.isupper():
        uc+=1
    elif char.islower():
        lc+=1
        
print("Upper case characters :", uc)
print("Lower case characters :", lc)


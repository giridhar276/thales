fobj = open("info.txt","w")
fobj.write("java and python programming\n")
fobj.write("unix shell")
fobj.close()

'''
\n : new line
\t : tab
'''

#fobj = open("C:/Users/gsripath/Desktop/new/info.txt","w")
fobj = open("C:\\Users\\gsripath\\Desktop\\new\\info.txt","w")
for val in range(1,10):
    fobj.write(str(val) + "\n")

fobj.close()
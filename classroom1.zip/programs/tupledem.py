

atup = (10,45,43,10,10,10)
print(atup)
btup = ("ML","DL","scala")
ctup = (34,443.33,"unix")


print(atup)

atup[0] = 10000

print("After modifying:", atup)


## converting from tuple to list
alist = list(atup)
# made my chages
alist[0] = 10000
# reconverting back to tuple
atup = tuple(alist)
print("After modifying :",atup)
from selenium import webdriver
import time
driver = webdriver.Chrome()

driver.get("https://www.linkedin.com/")

time.sleep(3)
driver.close()


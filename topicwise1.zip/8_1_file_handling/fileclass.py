#!/usr/bin/python

## file read program

fobj = open("demo.txt","r")

fobj.close()


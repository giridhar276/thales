


import pyautogui
im1 = pyautogui.screenshot()


for val in range(1,101):
    im2 = pyautogui.screenshot(str(val) + ".png")
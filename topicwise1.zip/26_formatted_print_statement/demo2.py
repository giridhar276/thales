print("My First name is {0} and last name is {1}".format("Giridhar","Sripathi"))

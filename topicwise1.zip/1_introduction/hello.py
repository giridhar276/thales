#!python
# printf(" hello from %d",&val)
import sys
sys.stdout.write("hello from python %s\n" %(sys.version))

#!/usr/bin/python

# assign variables

counter = 100
miles = 1000.0
name = "Giri"

# to print the variables

print("Variable integer :", counter)
print("Variable float :", miles )
print("Variable string :", name)


#multiple assignment applicable

var1 = var2 = var3 = 90

#to check the variable names
print("var1 :",var1)
print("var2 :",var2)
print("var3 :",var3)

var1,var2,var3 = 80,34.45,"Giridhar"

print("var1 :",var1)
print("var2 :",var2)
print("var3 :",var3)







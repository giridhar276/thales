import json
my_data = json.loads(open("colors.json").read())

print(my_data)
